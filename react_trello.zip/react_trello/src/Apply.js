// src/App.js
import React from 'react';
import './App.css';

const ExperienceItem = ({ title, company, duration, description }) => (
  <div className="experience-item">
    <h3>{title}</h3>
    <p>{company} | {duration}</p>
    <p>{description}</p>
  </div>
);

const EducationItem = ({ degree, school, graduationYear }) => (
  <div className="education-item">
    <h3>{degree}</h3>
    <p>{school} | {graduationYear}</p>
  </div>
);

const SkillItem = ({ skill }) => <li>{skill}</li>;

function App() {
  const resume = {
    name: 'Rahul Verma',
    title: 'React & React Native Developer',
    experience: [
      {
        title: 'Senior React Developer',
        company: 'Company A',
        duration: 'TCS | 2022-2023',
        description: 'Website & app. development along with UI designs',
      },
      // Add more experience entries as needed
    ],
    education: [
      {
        degree: 'Bachelor of Engineering in Computer Science',
        school: 'Mumbai University',
        graduationYear: '2019',
      },
      // Add more education entries as needed
    ],
    skills: ['React', 'React Native', 'JavaScript', 'HTML', 'CSS', 'Redux'],
    contact: {
      email: 'vrahul808700@gmail.com',
      linkedin: 'linkedin.com/rahulv',
      github: 'https://github.com/rahulrsverma',
    },
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>{resume.name}</h1>
        <p>{resume.title}</p>

        <section>
          <h2>Experience</h2>
          {resume.experience.map((exp, index) => (
            <ExperienceItem key={index} {...exp} />
          ))}
        </section>

        <section>
          <h2>Education</h2>
          {resume.education.map((edu, index) => (
            <EducationItem key={index} {...edu} />
          ))}
        </section>

        <section>
          <h2>Skills</h2>
          <ul>
            {resume.skills.map((skill, index) => (
              <SkillItem key={index} skill={skill} />
            ))}
          </ul>
        </section>

        <section>
          <h2>Contact</h2>
          <p>Email: {resume.contact.email}</p>
          <p>LinkedIn: {resume.contact.linkedin}</p>
          <p>GitHub: {resume.contact.github}</p>
        </section>
      </header>
    </div>
  );
}

export default App;
