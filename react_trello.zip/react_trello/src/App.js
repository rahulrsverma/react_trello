import React, { useState } from 'react';
import './App.css'
import axios from 'axios';


const FormComponent = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [startDate, setStartDate] = useState('');
  
  const [nameError, setNameError] = useState('');
  const [descriptionError, setDescriptionError] = useState('');
  const [dueDateError, setDueDateError] = useState('');
  const [startDateError, setStartDateError] = useState('');

  const validateDueDate = (value) => {
   
    const currentDate = new Date();
    const selectedDate = new Date(value);

    if (selectedDate <= currentDate) {
      return 'Due date must be in the future';
    }

    return '';
  };

  const validateStartDate = (value) => {
    
    const currentDate = new Date();
    const selectedDate = new Date(value);

    if (selectedDate >= currentDate) {
      return 'Start date must be in the past';
    }

    return '';
  };



  const handleNameChange = (e) => {
    const value = e.target.value;
    setName(value);
    setNameError(value.trim() === '' ? 'Name is required' : '');
  };
  
  const handleDescriptionChange = (e) => {
    const value = e.target.value;
    setDescription(value);
    setDescriptionError(value.trim() === '' ? 'Description is required' : '');
  };
  
  const handleDueDateChange = (e) => {
    const value = e.target.value;
    setDueDate(value);
    setDueDateError(validateDueDate(value)); // You need to implement the validateDueDate function
  };
  
  const handleStartDateChange = (e) => {
    const value = e.target.value;
    setStartDate(value);
    setStartDateError(validateStartDate(value)); // You need to implement the validateStartDate function
  };
  
  

  const handleSubmit = async (e) => {
    e.preventDefault();

    //  your Trello API key and token
    const apiKey = 'c9b8ccfd38d6c7412c0c98d6dada4373';
    const token = 'ATTA4d03838e59797c374967514437302762e47c0e66de785abfba5d61c9a44cc5956C7EF68A';

    //  your Trello board ID
    //const id = '4WzfbAtG';

    const listid = '65a2dbcb8c07dfe0741fe148';

    // Trello API URL for creating a card
    const apiUrl = `https://api.trello.com/1/cards?key=${apiKey}&token=${token}&idList=${listid}&name=${name}&desc=${description}&due=${dueDate}&dueComplete=false`;
    //const apiUrl = `https://api.trello.com/1/boards/${id}/lists?key=${apiKey}&token=${token}`;

    try {
      //const response = await axios.get(apiUrl);
      const response = await axios.post(apiUrl);
      console.log(response.data);
      //  logic to handle success or navigate to another page
    } catch (error) {
      console.error('Error creating Trello card:', error);
      // Handle error appropriately
    }
  };

  return (
    <div className="form-container">
      <label>Trello Form</label>
      <form onSubmit={handleSubmit}>
      <label>
  <span>Name:</span>
  <input type="text" value={name} onChange={handleNameChange} />
  {nameError && <span className="error">{nameError}</span>}
</label>

<label>
  <span>Description:</span>
  <textarea value={description} onChange={handleDescriptionChange} />
  {descriptionError && <span className="error">{descriptionError}</span>}
</label>

<label>
  <span>Due Date:</span>
  <input type="text" value={dueDate} onChange={handleDueDateChange} />
  {dueDateError && <span className="error">{dueDateError}</span>}
</label>

<label>
  <span>Start Date:</span>
  <input type="text" value={startDate} onChange={handleStartDateChange} />
  {startDateError && <span className="error">{startDateError}</span>}
</label>

        
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default FormComponent;
